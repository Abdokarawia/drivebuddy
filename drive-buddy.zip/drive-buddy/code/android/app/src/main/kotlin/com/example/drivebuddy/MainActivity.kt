package com.example.drivebuddy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
