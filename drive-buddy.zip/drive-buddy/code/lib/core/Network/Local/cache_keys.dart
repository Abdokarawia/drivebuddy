abstract class CacheKeys {
  static const hasVisitedOnboarding = 'hasVisitedOnboarding';
  static const accessToken = 'accessToken';
  static const rememberAccount = 'rememberAccount';
}
