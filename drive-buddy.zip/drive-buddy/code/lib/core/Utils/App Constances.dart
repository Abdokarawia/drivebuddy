abstract class AppConstances {
  static bool? isOnBoarding;
  static String locale = 'en';
  static String visitsBox = "VisitsDB";
  static String savedAction = "savedActionDB";
  static String requestsByVisitIdBox = "requestsByVisitIdDB";
  static String userData = "userData";
  static String? token = 'Tlq6Ow44srFPReO1oKIrSSnpDixu2cOG5BIlVT7hjrST1NhSvmJxwm9OmQf8O6iP0KNcqh';
  static const key = "JjwhRNk6vkyzfOpAGaAW1A==";

}